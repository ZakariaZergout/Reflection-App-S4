import SwiftUI

struct FeedbackView: View {
    var body: some View {
        NavigationView {
            
            VStack{
                HStack {
                    Text("Apps")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    Spacer()
                    
                    Image("Profile Icon")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                }
                .padding(.all, 30)
                
                
                Text("One Minute Reflections")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color(red: 0.522, green: 0.815, blue: 0.975))
                    .multilineTextAlignment(.leading)
                    .padding(.trailing, 45.0)
                    .frame(width: 500.0, height: 50.0)
                HStack{
                    
                    Image("Video Section").resizable().padding(.leading, 25.0).frame(width: 390, height: 300)
                    
                }
                
                VStack{
                    
                    Text("Note Options")
                        .font(.title)
                        .fontWeight(.semibold)
                        .foregroundColor(Color(red: 0.522, green: 0.815, blue: 0.975))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 170.0)
                    
                    
                    HStack{
                        
                        HStack(alignment: .center, spacing: 0.0){
                            
                            
                            VStack {
                                
                                NavigationLink(destination: ContentView(audioRecorder: AudioRecorder())) {
                                    Image("Button Voice")
                                }
                            }
                            
                            
                            
                            VStack {
                                Image("Button Video")
                                NavigationLink(destination: FeedbackView()) {
                                    
                                }
                            }.padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        }
                        

                        
                    }
                    
                    
                    
                }.padding(.vertical, 35.0)
                
                HStack{
                    
                    Image("Nav Bar")
                    
                }
                .padding(.bottom, -30.0)
                
            }
        }
    }
}



struct FeedbackView_Previews: PreviewProvider {
    static var previews: some View {
        FeedbackView()
    }
}
