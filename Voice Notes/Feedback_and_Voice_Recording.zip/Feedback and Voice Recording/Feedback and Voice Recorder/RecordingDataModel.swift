import Foundation

struct Recording {
    let fileURL: URL
    let createdAt: Date
}
