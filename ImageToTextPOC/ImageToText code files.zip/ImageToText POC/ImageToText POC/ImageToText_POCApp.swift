//
//  ImageToText_POCApp.swift
//  ImageToText POC
//
//  Created by Zakaria Zergout  on 16/01/2023.
//

import SwiftUI

@main
struct ImageToText_POCApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
