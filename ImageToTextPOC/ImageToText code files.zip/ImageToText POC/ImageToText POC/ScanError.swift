//
//  ScanError.swift
//  ImageToText POC
//
//  Created by Zakaria Zergout  on 16/01/2023.
//

import Foundation

// https://developer.apple.com/documentation/swift/error
struct ScanError: Error {
    let id = UUID()
}

extension ScanError: Equatable {
    static func ==(lhs: ScanError, rhs: ScanError) -> Bool {
        return lhs.id == rhs.id
    }
}

