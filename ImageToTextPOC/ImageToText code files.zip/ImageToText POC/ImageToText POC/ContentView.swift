//
//  ContentView.swift
//  ImageToText POC
//
//  Created by Zakaria Zergout  on 16/01/2023.
//

import SwiftUI
import AVFoundation
import VisionKit
import Combine

struct ContentView: View {
    
    @State var cancelPressed = false
    @State var scanError: ScanError?
    @State var scanResult: VNDocumentCameraScan?
    
    @State var recognizedText = "Processing ..."
    @State var scanMode = true
    
    var textScanner = TextScanner()
    
    var body: some View {
        activeView
    }
    
    @ViewBuilder
    var activeView: some View {
        if (scanMode) {
            DocumentCameraView(cancelPressed: $cancelPressed, error: $scanError, scanResult: $scanResult)
                .onChange(of: scanResult, perform: process(scanResult:))
                .onChange(of: scanError, perform: notify(error:))
                .onChange(of: cancelPressed, perform: toggleScanMode(mode:))
                .onReceive(textScanner.$recognizedText, perform: { stringValue in self.recognizedText = stringValue })
        } else {
            resultView
        }
    }
    
    var resultView: some View {
        NavigationView {
            ScrollView {
                Text(recognizedText).padding()
            }.toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button(action: { toggleScanMode(mode: true) }) {
                        Image(systemName: "doc.viewfinder")
                    }
                }
            }
        }
    }
    
    func process(scanResult: VNDocumentCameraScan?) {
        guard let scanResult = scanResult else { return }
        toggleScanMode(mode: false)
        textScanner.subject.send(scanResult)
    }
    
    func notify(error: ScanError?) {
        guard let error = error else { return }
        NSLog(error.localizedDescription)
    }
    
    func toggleScanMode(mode: Bool) {
        withAnimation(.easeInOut(duration: 1.0)) {
            scanMode.toggle()
        }
    }
}
