//
//  DocumentCameraView.swift
//  ImageToText POC
//
//  Created by Zakaria Zergout  on 16/01/2023.
//

import Foundation
import SwiftUI
import VisionKit

struct DocumentCameraView: UIViewControllerRepresentable {
    
    @Binding var cancelPressed: Bool
    @Binding var error: ScanError?
    @Binding var scanResult: VNDocumentCameraScan?
    
    typealias UIViewControllerType = VNDocumentCameraViewController
    
    func makeUIViewController(context: Context) -> UIViewControllerType {
        let myViewController = UIViewControllerType()
        myViewController.delegate = context.coordinator
        return myViewController
    }
    
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        // left blank
    }
    
    func makeCoordinator() -> DocumentCameraView.Coordinator {
        return Coordinator(self)
    }
}

extension DocumentCameraView {
    class Coordinator : NSObject, VNDocumentCameraViewControllerDelegate {
        var parent: DocumentCameraView
        
        init(_ parent: DocumentCameraView) {
            self.parent = parent
        }
        
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            parent.cancelPressed.toggle()
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
            parent.error = error as? ScanError
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            parent.scanResult = scan
        }
    }
}

